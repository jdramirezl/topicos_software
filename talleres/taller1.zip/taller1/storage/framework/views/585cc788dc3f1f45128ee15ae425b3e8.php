<?php $__env->startSection('title', 'Home Page - Online Store'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Taller 1: Topicos Ing. Software</div>

                <div class="card-body text-center">
                    <h1>Clase: Base Drone </h1>
                    <p>Elija a que punto quiere ir</p>

                    <div class="card">
                        <a href="<?php echo e(route('drones.create')); ?>" class="btn btn-primary">Act 2: Insercion</a>
                        <a href="<?php echo e(route('drones.index')); ?>" class="btn btn-primary">Act 4: Listar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/julianramire/Desktop/eafit/septimo/software/GITHUB_FOLDERS/talleres/taller1/resources/views/home/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Home Page - Online Store'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Clase: Base Drone </div>

                <div class="card-body text-center">
                    <h1>Welcome to Our Homepage</h1>
                    <p>This is a simple homepage with centered buttons.</p>

                    <div class="mt-3">
                        <a href="#" class="btn btn-primary">Button 1</a>
                        <a href="#" class="btn btn-secondary">Button 2</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/julianramire/Desktop/eafit/septimo/software/taller1/taller1/resources/views/home/index.blade.php ENDPATH**/ ?>